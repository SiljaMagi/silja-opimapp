(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Kausspsd = function() {
	this.initialize(img.Kausspsd);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,197);


(lib.koolpsd_0jpgcopy = function() {
	this.initialize(img.koolpsd_0jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,618,500);


(lib.peremetsas_alt = function() {
	this.initialize(img.peremetsas_alt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3877,3971);


(lib.väiksem = function() {
	this.initialize(img.väiksem);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,889,500);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("AoLC1QhLgBg0g0Qg1g1AAhLQAAhJA1g1QA0g1BLAAIQXAAQBLAAA1A1QA0A1AABJQAABLg0A1Qg1A0hLABg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.4,-18,140.9,36.1);


(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("AoLC1QhLgBg0g0Qg1g1AAhLQAAhJA1g1QA0g1BLAAIQXAAQBLAAA1A1QA0A1AABJQAABLg0A1Qg1A0hLABg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.4,-18,140.9,36.1);


(lib.Tween15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYApQgLgEgGgLQgHgLABgPQgBgNAHgKQAGgKALgGQALgGANAAQAPAAAKAFQAMAGAGAJQAFAKABANIgBAHIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAbAAIAAACQgBAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgFgEQgEgEgNAAQgNAAgFAFg");
	this.shape.setTransform(49.65,1.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAAKAFQAMAGAFAJQAGAKAAANIAAADIAAAEIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgEAAgFIAAgCIAaAAIAAACQAAAJgFAIQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgGgEgMAAQgMAAgGAFg");
	this.shape_1.setTransform(39.125,1.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQAPIAAgdIAhAAIAAAdg");
	this.shape_2.setTransform(31.6,4.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYApQgKgEgIgLQgFgLAAgPQAAgNAFgKQAHgKALgGQALgGANAAQAPAAALAFQALAGAGAJQAFAKAAANIgBAHIhGAAQAAAKAFAFQAGAFAMAAQALAAAGgDQAEgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgKAFQgLAEgOAAQgPAAgKgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgFgEgNAAQgMAAgGAFg");
	this.shape_3.setTransform(24.15,1.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AggAoQgIgEgEgIQgEgJAAgJIAAg2IAaAAIAAAtQAAALAFAEQAFAFAMAAQANAAAFgFQAFgFAAgKIAAgtIAaAAIAABXIgYAAIAAgbIgCAAQAAAIgFAGQgDAGgIAFQgIAEgLAAQgMAAgIgFg");
	this.shape_4.setTransform(13.275,1.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgZAoQgMgGgGgKQgGgKAAgOQAAgNAGgKQAGgKAMgGQAMgGANAAQAOAAAMAGQAMAGAGAKQAGAKAAANQAAAOgGAKQgGAKgMAGQgMAGgOAAQgNAAgMgGgAgSgQQgFAGAAAKQAAALAFAGQAFAFANAAQAOAAAFgFQAFgGAAgLQAAgKgFgGQgGgGgNAAQgMAAgGAGg");
	this.shape_5.setTransform(2.275,1.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQALgGAOAAQAPAAAKAFQAMAGAEAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAFgDQAEgDAAgGIAAgCIAbAAIAAACQAAAKgGAHQgGAHgKAFQgLAEgOAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQAAgJgFgEQgFgEgNAAQgMAAgGAFg");
	this.shape_6.setTransform(-8.375,1.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgpAtIAAhXIAZAAIAAAXIABAAQACgIAEgEQADgGAGgDQAEgEAKAAQAJAAAHAEQAGAFADAGQADAJAAAHIAAAOIgaAAIAAgJQgBgGgDgEQgDgDgIAAQgIAAgDAEQgEADAAAIIAAAzg");
	this.shape_7.setTransform(-18.05,1.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AASA7IgUggIgUAAIAAAgIgbAAIAAh1IAbAAIAAA+IAUAAIAVggIAfAAIggAqIAgAtg");
	this.shape_8.setTransform(-27.85,-0.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfAlQgMgIAAgPIAAgBIAaAAIAAACQAAAGAFACQADACALAAQAKAAAEgCQAEgCAAgEQAAgDgDgCQgDgCgIAAIgYgDQgNgCgHgFQgGgFgBgMQAAgIAFgGQAEgGAKgEQALgEANAAQAMAAAMAEQAKADAGAIQAFAIAAAKIAAAAIgbAAIAAgBQABgDgCgDQgBgCgFgCIgLgBQgKAAgDACQgEACAAAEQABADACACQADACAJABIARACQASACAHAFQAIAGgBALQABAIgGAHQgGAGgJADQgJAEgOAAQgUAAgNgJg");
	this.shape_9.setTransform(-38.45,1.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMA7IAAhXIAZAAIAABXgAgMglIAAgVIAZAAIAAAVg");
	this.shape_10.setTransform(-45.4,-0.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAMA0QgOAAgJgHQgJgIAAgQIAAgiIgNAAIAAgVIANAAIAAgRIAaAAIAAARIAcAAIAAAVIgcAAIAAAfQAAAHADACQACACAHAAIAQAAIAAAXg");
	this.shape_11.setTransform(-51.125,0.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-5.9,109,11.9);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYApQgLgEgGgLQgHgLABgPQgBgNAHgKQAGgKALgGQALgGANAAQAPAAAKAFQAMAGAGAJQAFAKABANIgBAHIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAbAAIAAACQgBAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgFgEQgEgEgNAAQgNAAgFAFg");
	this.shape.setTransform(49.7,1.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAAKAFQAMAGAFAJQAGAKAAANIAAADIAAAEIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgEAAgFIAAgCIAaAAIAAACQAAAJgFAIQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgGgEgMAAQgMAAgGAFg");
	this.shape_1.setTransform(39.175,1.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQAPIAAgdIAhAAIAAAdg");
	this.shape_2.setTransform(31.65,4.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYApQgKgEgIgLQgFgLAAgPQAAgNAFgKQAHgKALgGQALgGANAAQAPAAALAFQALAGAGAJQAFAKAAANIgBAHIhGAAQAAAKAFAFQAGAFAMAAQALAAAGgDQAEgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgKAFQgLAEgOAAQgPAAgKgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgFgEgNAAQgMAAgGAFg");
	this.shape_3.setTransform(24.2,1.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AggAoQgIgEgEgIQgEgJAAgJIAAg2IAaAAIAAAtQAAALAFAEQAFAFAMAAQANAAAFgFQAFgFAAgKIAAgtIAaAAIAABXIgYAAIAAgbIgCAAQAAAIgFAGQgDAGgIAFQgIAEgLAAQgMAAgIgFg");
	this.shape_4.setTransform(13.325,1.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgZAoQgMgGgGgKQgGgKAAgOQAAgNAGgKQAGgKAMgGQAMgGANAAQAOAAAMAGQAMAGAGAKQAGAKAAANQAAAOgGAKQgGAKgMAGQgMAGgOAAQgNAAgMgGgAgSgQQgFAGAAAKQAAALAFAGQAFAFANAAQAOAAAFgFQAFgGAAgLQAAgKgFgGQgGgGgNAAQgMAAgGAGg");
	this.shape_5.setTransform(2.325,1.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQALgGAOAAQAPAAAKAFQAMAGAEAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAFgDQAEgDAAgGIAAgCIAbAAIAAACQAAAKgGAHQgGAHgKAFQgLAEgOAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQAAgJgFgEQgFgEgNAAQgMAAgGAFg");
	this.shape_6.setTransform(-8.325,1.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgpAtIAAhXIAZAAIAAAXIABAAQACgIAEgEQADgGAGgDQAEgEAKAAQAJAAAHAEQAGAFADAGQADAJAAAHIAAAOIgaAAIAAgJQgBgGgDgEQgDgDgIAAQgIAAgDAEQgEADAAAIIAAAzg");
	this.shape_7.setTransform(-18,1.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AASA7IgUggIgUAAIAAAgIgbAAIAAh1IAbAAIAAA+IAUAAIAVggIAfAAIggAqIAgAtg");
	this.shape_8.setTransform(-27.8,-0.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfAlQgMgIAAgPIAAgBIAaAAIAAACQAAAGAFACQADACALAAQAKAAAEgCQAEgCAAgEQAAgDgDgCQgDgCgIAAIgYgDQgNgCgHgFQgGgFgBgMQAAgIAFgGQAEgGAKgEQALgEANAAQAMAAAMAEQAKADAGAIQAFAIAAAKIAAAAIgbAAIAAgBQABgDgCgDQgBgCgFgCIgLgBQgKAAgDACQgEACAAAEQABADACACQADACAJABIARACQASACAHAFQAIAGgBALQABAIgGAHQgGAGgJADQgJAEgOAAQgUAAgNgJg");
	this.shape_9.setTransform(-38.4,1.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMA7IAAhXIAZAAIAABXgAgMglIAAgVIAZAAIAAAVg");
	this.shape_10.setTransform(-45.35,-0.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAMA0QgOAAgJgHQgJgIAAgQIAAgiIgNAAIAAgVIANAAIAAgRIAaAAIAAARIAcAAIAAAVIgcAAIAAAfQAAAHADACQACACAHAAIAQAAIAAAXg");
	this.shape_11.setTransform(-51.075,0.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-5.9,109.1,11.9);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("A/eJAIAAx/MA+9AAAIAAR/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-201.4,-57.6,402.9,115.2);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("A/eJAIAAx/MA+9AAAIAAR/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-201.4,-57.6,402.9,115.2);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("EgI/AoWMAAAhQrIR/AAMAAABQrg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.6,-258.2,115.30000000000001,516.5);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("EgI/AoWMAAAhQrIR/AAMAAABQrg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.6,-258.2,115.30000000000001,516.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("A/dJAIAAx/MA+7AAAIAAR/g");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-201.4,-57.6,402.9,115.2);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("A/dJAIAAx/MA+7AAAIAAR/g");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-201.4,-57.6,402.9,115.2);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuskool
	this.instance = new lib.koolpsd_0jpgcopy();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(125).to({_off:true},1).wait(1).to({_off:false},0).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,618,500);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_7
	this.instance = new lib.väiksem();
	this.instance.setTransform(0,0,1.0036,1.0036);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(194));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,687,386.4);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tekst
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAPIAAgdIATAAIAAAdg");
	this.shape.setTransform(188.975,40.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgoAxQgKgHAAgNQAAgJAEgGQAFgFAIgEQAJgDAJAAIAzgGIAAgIQAAgPgIgHQgIgIgRABQgQAAgJAGQgKAHAAAOIAAABIgPAAIAAgBQgBgLAHgKQAGgKAMgFQAMgGAPAAQAQABALAFQAKAFAFALQAFAJAAAMIAABEIgOAAIAAgeIgBAAQgGAPgNAIQgMAJgTAAQgRAAgJgIgAgKALQgNACgGADQgFADgBAJQABAIAFAEQAGAEAMABQAOgBAKgEQAJgDAIgJQAGgJAAgMIAAgBg");
	this.shape_1.setTransform(181,36.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgJAPIAAgdIATAAIAAAdg");
	this.shape_2.setTransform(173.525,40.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgiBEQgPgIgIgRQgHgSAAgZQAAgQAEgOQAFgOAIgKQAIgKANgFQALgGASAAQAQAAAOAGQANAGAHAKQAIAKAAAPIAAACIgRAAIAAgCQAAgKgEgGQgEgHgJgFQgKgEgOAAQgSAAgLAHQgMAGgEANQgFAMAAAVIAAAMIABAAQACgIAIgFQAHgHAMgEQAMgEANAAQASAAAMAGQAMAFAIAKQAHAKAAAPQAAAVgQANQgQANgeAAQgXAAgOgIgAgWgBQgLADgGAHQgFAHAAAKQAAAMAFAHQAGAJALADQAKAEAPAAQAQAAAKgEQALgEAEgHQAFgHAAgLQAAgMgFgHQgFgHgKgDQgLgEgPAAQgOAAgLAEg");
	this.shape_3.setTransform(164.475,34.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag5BLIAAgLQAAgPADgJQAEgJAJgIQALgHANgFIAggLQAIgCAJgGQAGgEADgFQACgFAAgJQAAgJgEgHQgFgFgJgEQgJgDgOAAQgOAAgLAEQgKAEgFAIQgEAHAAALIAAADIgQAAIAAgCQAAgOAGgLQAHgLANgHQAMgHAXAAQATAAAMAGQANAGAGAKQAGAKAAALQAAAMgFAIQgEAIgJAFQgJAHgNAEIgdAKQgNAFgGAEQgGAEgDAIQgDAJAAAJIBkgCIAAAPg");
	this.shape_4.setTransform(150.4,34.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgjBDQgPgJgJgRQgIgRAAgYQAAgXAIgRQAKgSAOgIQAPgJAUAAQAVAAAPAJQAPAJAJARQAIASAAAWQAAAXgIASQgIAQgQAKQgPAJgVAAQgUAAgPgJgAgcg1QgLAHgGANQgGAOAAATQAAAUAGAOQAGANALAHQALAHARAAQARAAALgHQAMgGAGgOQAGgNAAgVQAAgUgGgNQgGgOgMgGQgLgHgRAAQgRAAgLAHg");
	this.shape_5.setTransform(136.025,34.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag6BLIAAgLQABgOAEgKQADgKAJgHQAKgHAOgFIAggLQAIgDAIgFQAGgDADgGQADgGAAgIQAAgJgFgHQgDgFgKgEQgJgDgPAAQgNAAgLAEQgKAEgEAIQgGAHAAALIAAADIgPAAIAAgCQAAgOAGgLQAHgLANgHQANgHAVAAQAUAAANAGQAMAGAGAKQAGAKAAALQAAAMgFAIQgEAIgJAFQgJAGgNAFIgdAKQgMAEgHAFQgGAEgDAIQgEAIAAAKIBkgCIAAAPg");
	this.shape_6.setTransform(121.75,34.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgJAPIAAgdIATAAIAAAdg");
	this.shape_7.setTransform(113.325,40.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgfBGQgNgFgIgLQgHgKAAgPIAAgCIAQAAIAAACQAAAIAEAIQAFAIAIAEQAIAEARAAQASAAAKgHQAMgHAEgNQAFgNAAgVIAAgMIgBAAQgDAJgHAGQgGAGgNAFQgMAEgNAAQgRAAgNgGQgNgGgHgJQgHgKAAgPQAAgVAQgNQAQgNAeAAQAWAAAPAIQAPAHAIARQAHARAAAaQAAAQgEAPQgFAOgIAKQgHAKgNAFQgMAGgRAAQgSAAgMgGgAgcg4QgLAEgEAHQgFAHAAAMQAAALAFAHQAFAIAKACQAJAEARAAQAOAAALgEQAKgDAHgIQAFgIAAgKQAAgKgFgIQgGgIgKgDQgKgEgQAAQgQAAgKAEg");
	this.shape_8.setTransform(104.275,34.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgjBDQgPgJgJgRQgIgRAAgYQAAgXAIgRQAKgSAOgIQAPgJAUAAQAVAAAPAJQAPAJAJARQAIASAAAWQAAAXgIASQgIAQgQAKQgPAJgVAAQgUAAgPgJgAgcg1QgLAHgGANQgGAOAAATQAAAUAGAOQAGANALAHQALAHARAAQARAAALgHQAMgGAGgOQAGgNAAgVQAAgUgGgNQgGgOgMgGQgLgHgRAAQgRAAgLAHg");
	this.shape_9.setTransform(89.275,34.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgJAPIAAgdIATAAIAAAdg");
	this.shape_10.setTransform(80.025,40.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAKBKIAAh0IgiAAIAAgMIAIAAQAMAAAGgEQAGgEAFgLIAMAAIAACTg");
	this.shape_11.setTransform(74.575,34.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgaBCQgLgJgEgQIgCAAIAAAgIgOAAIAAiTIAQAAIAABFIABAAQADgNAMgKQAMgJASAAQASAAALAHQAMAHAGANQAGAMAAAQQAAARgGANQgGAMgMAIQgLAHgTAAQgSAAgMgJgAgegMQgLALAAATIAAACQAAANAFAJQAFAJAKAFQAJAFAMAAQANAAAKgEQAKgFAEgJQAFgJAAgQQAAgPgFgJQgFgIgJgFQgKgEgNAAQgSAAgMALg");
	this.shape_12.setTransform(61.4,34.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgHANIAAgYIAPAAIAAAYg");
	this.shape_13.setTransform(52.225,28.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgHA2IAAhrIAPAAIAABrg");
	this.shape_14.setTransform(52.225,36.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("ABNA4IAAg8QAAgSgHgJQgJgJgRAAQgUAAgIALQgIAKAAAWIAAA1IgPAAIAAg8QAAgTgIgIQgIgJgRAAQgUAAgIALQgJAKAAAWIAAA1IgPAAIAAhsIAOAAIAAAgIAAAAQADgKAEgHQAFgHAJgFQAKgFAMgBQAPAAAJAHQAJAGAEALQACAGABAGIACAAQABgHAFgKQAGgJAIgEQAKgGANAAQAOAAAKAHQAKAGAEALQAFALAAANIAAA/g");
	this.shape_15.setTransform(39.575,36.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgHBKIAAiTIAPAAIAACTg");
	this.shape_16.setTransform(26.825,34.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgoAxQgKgGAAgOQAAgJAEgGQAFgGAIgDQAJgDAJAAIAzgGIAAgIQAAgPgIgHQgIgIgRABQgQAAgKAGQgJAHAAAOIAAABIgQAAIAAgBQAAgLAHgKQAFgJANgGQAMgGAOAAQARABAKAFQALAFAFALQAFAKAAALIAABEIgOAAIAAgeIgBAAQgFAPgNAIQgOAJgSAAQgRAAgJgIgAgLALQgMACgGADQgFADAAAJQgBAIAGAEQAGAEAMABQAOgBAJgEQALgDAGgJQAHgIAAgNIAAgBg");
	this.shape_17.setTransform(18.4,36.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgJA2IgzhrIARAAIArBcIABAAIAshcIAQAAIgzBrg");
	this.shape_18.setTransform(6.15,36.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgHBKIAAiTIAPAAIAACTg");
	this.shape_19.setTransform(354.525,7.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgoAyQgKgIAAgNQAAgJAFgFQAEgHAIgCQAJgEAJgBIAzgEIAAgJQAAgPgIgIQgIgGgSAAQgPgBgKAHQgJAHAAAOIAAABIgQAAIAAgBQABgLAFgKQAGgJAMgGQAMgFAQgBQAQAAAKAHQAMAFAEAKQAFAKAAAMIAABCIgOAAIAAgdIgBAAQgFAPgNAJQgNAHgTABQgRgBgJgGgAgKALQgNABgGAEQgFADAAAJQAAAIAFAFQAGADAMAAQAOAAAJgDQAKgEAIgJQAFgIABgNIAAgBg");
	this.shape_20.setTransform(346.1,9.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgJA2Ig0hrIARAAIAsBcIAAAAIAshcIASAAIg1Brg");
	this.shape_21.setTransform(333.9,9.775);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgsA3IAAhrIAPAAIAAAeIABAAQABgJAEgHQAFgIAJgEQAHgEAKgBQANABAIAFQAJAHADAHQAEAKAAAJIAAALIgQAAIAAgIQAAgOgGgHQgGgHgPABQgPgBgHAKQgIAKAAATIAAA5g");
	this.shape_22.setTransform(322.55,9.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAJALIgRgLIgGgBQAAAAgBAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgCABAAAFIAAAGIgLAAIAAgIIABgIQACgEAEgCQACgCAHAAQAEAAAEACIAQAKQACABADAAQABAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQACgBAAgFIAAgGIALAAIAAAIQAAAHgEAFQgEAFgGAAQgGAAgDgCg");
	this.shape_23.setTransform(310.1,1.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgeAyQgOgJgGgLQgIgNAAgRQAAgPAIgNQAHgNANgHQAOgHAQgBQATABAMAHQAOAHAGANQAIANAAAPQAAARgIANQgGALgOAJQgMAGgTABQgRgBgNgGgAgggeQgKALAAATQAAAUAKAMQALALAVAAQAXAAAKgLQALgMAAgUQAAgTgLgLQgKgMgXABQgVgBgLAMg");
	this.shape_24.setTransform(310.1,9.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAjBKIgkgxIgkAAIAAAxIgQAAIAAiTIAQAAIAABUIAkAAIAkgtIASAAIgqAzIAqA5g");
	this.shape_25.setTransform(297.9,7.825);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgcAyQgNgHgHgNQgHgMAAgSQAAgQAHgMQAHgNANgHQANgHAQgBQAQAAAMAHQAMAFAIAMQAHALAAARIgBAJIhfAAQAAAQAKAMQAJALAWgBQAUAAAIgGQAJgHAAgMIAAgBIAQAAIAAABQAAALgHAKQgGAHgNAGQgMAFgPAAQgQAAgNgHgAgegfQgJAJgBASIBRAAIAAgEQAAgQgKgKQgLgIgTgBQgVAAgKAMg");
	this.shape_26.setTransform(280.875,9.75);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAPBDQgPAAgJgHQgKgJAAgSIAAg8IgTAAIAAgNIATAAIAAgaIAQAAIAAAaIAqAAIAAANIgqAAIAAA9QAAALAFAEQAFAEANAAIATAAIAAAOg");
	this.shape_27.setTransform(270.2,8.475);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AghAxQgKgGgFgLQgFgMAAgMIAAg+IAQAAIAAA8QgBAQAJAKQAJAJATAAQATAAAKgLQAKgLAAgVIAAg0IAQAAIAABrIgOAAIAAgiIgCAAQgBAJgGAJQgGAIgJAFQgKAFgNAAQgQAAgKgGg");
	this.shape_28.setTransform(259.45,9.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAQBDQgQAAgJgHQgKgJAAgSIAAg8IgTAAIAAgNIATAAIAAgaIAQAAIAAAaIAqAAIAAANIgqAAIAAA9QAAALAFAEQAFAEAMAAIAUAAIAAAOg");
	this.shape_29.setTransform(248.475,8.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgkAvQgOgKAAgTIAQAAIAAABQAAAOAJAFQAIAFATAAQATAAAHgEQAHgEAAgKQAAgJgFgCQgGgFgOgCIgcgDQgOgCgJgGQgJgGAAgOQAAgLAGgFQAFgHALgFQAMgEAOAAQAPABALAEQANAFAFAIQAHAIAAANIAAABIgQAAIAAgCQAAgHgDgGQgDgFgIgDQgIgDgNgBQgRAAgIAFQgIAFAAAJQAAAIAGAEQAFAEANACIAaAEQARACAJAGQAKAGAAANQAAALgHAHQgGAHgLADQgKAEgPAAQgYAAgOgKg");
	this.shape_30.setTransform(238.625,9.75);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgHA2IAAhrIAPAAIAABrg");
	this.shape_31.setTransform(230.675,9.775);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgHAMIAAgYIAPAAIAAAYg");
	this.shape_32.setTransform(230.675,1.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAmA3IAAg7QAAgRgJgKQgJgJgSAAQgTAAgKAMQgKALAAAUIAAA0IgPAAIAAhrIANAAIAAAiIACAAQACgJAFgJQAHgJAIgEQALgFAMgBQAOABALAGQALAHAEALQAGAJAAAOIAAA+g");
	this.shape_33.setTransform(222,9.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAmA3IAAg7QAAgSgJgJQgIgJgTAAQgTAAgKAMQgKAKAAAVIAAA0IgQAAIAAhrIAOAAIAAAiIACAAQABgJAGgJQAHgJAJgEQAJgFANgBQAPABAKAGQALAHAEALQAGAKAAANIAAA+g");
	this.shape_34.setTransform(208.725,9.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgHA2IAAhrIAPAAIAABrg");
	this.shape_35.setTransform(199.975,9.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgHAMIAAgYIAPAAIAAAYg");
	this.shape_36.setTransform(199.975,1.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AAjBKIgkgxIgkAAIAAAxIgPAAIAAiTIAPAAIAABUIAlAAIAjgtIASAAIgqAzIAqA5g");
	this.shape_37.setTransform(192.325,7.825);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgkAvQgOgKABgTIAQAAIAAABQgBAOAJAFQAIAFAUAAQATAAAGgEQAIgEgBgKQABgJgGgCQgGgEgNgDIgdgDQgPgCgIgGQgJgGAAgOQAAgKAGgGQAGgHAKgFQAMgEAOAAQAPABALAEQANAFAFAIQAHAJAAAMIAAABIgQAAIAAgCQAAgHgDgGQgEgFgHgDQgIgDgNgBQgSAAgHAFQgIAFABAJQgBAIAGAEQAEAEAOACIAaAEQARACAJAGQAKAGAAANQAAAKgHAIQgGAHgKADQgLAEgOAAQgZAAgOgKg");
	this.shape_38.setTransform(175.8,9.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAjBKIgjgxIglAAIAAAxIgPAAIAAiTIAPAAIAABUIAlAAIAjgtIATAAIgrAzIArA5g");
	this.shape_39.setTransform(164.4,7.825);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgcAyQgNgHgHgNQgHgMAAgSQAAgQAHgMQAHgNANgHQANgHAQgBQAQAAAMAHQAMAFAIAMQAHALAAARIgBAJIhfAAQABARAJALQAJALAWgBQAUAAAIgGQAJgHAAgMIAAgBIAQAAIAAABQAAALgHAKQgGAHgNAGQgMAFgPAAQgQAAgNgHgAgegfQgJAJgBASIBRAAIAAgEQAAgQgKgKQgLgIgTgBQgVAAgKAMg");
	this.shape_40.setTransform(151.425,9.75);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgHBKIAAiTIAPAAIAACTg");
	this.shape_41.setTransform(142.975,7.825);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("Ag5BKIAAiRIAOAAIAAAfIACAAQAEgPAMgJQAMgJARAAQARAAAMAHQAMAHAGANQAHANAAAQQAAARgGAMQgHAMgMAIQgKAHgTAAQgQAAgNgJQgMgJgEgQIAAAAIAABFgAgegwQgLAMAAATIAAACQAAANAFAIQAFAJAJAFQAKAFAMAAQAMAAAKgEQAKgFAFgJQAFgHAAgRQAAgPgFgKQgFgIgKgFQgJgEgMAAQgTAAgMALg");
	this.shape_42.setTransform(134.5,11.525);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("ABOA3IAAg7QAAgSgIgJQgJgJgRAAQgUAAgIALQgIALAAAVIAAA0IgPAAIAAg7QAAgSgIgJQgIgJgRAAQgUAAgIALQgJALAAAVIAAA0IgPAAIAAhrIAOAAIAAAhIABAAQABgKAFgIQAEgHAKgFQAKgGAMAAQAPABAJAGQAJAGAEALIAEANIABAAQABgJAFgJQAGgJAJgEQAJgFANgBQAPABAJAGQAKAGAEALQAFAJAAAPIAAA+g");
	this.shape_43.setTransform(116.825,9.65);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgeAyQgNgJgHgLQgIgNAAgRQAAgPAIgNQAIgNAMgHQAOgHAQgBQASABANAHQANAHAIANQAHAMAAAQQAAASgHAMQgHALgOAJQgMAGgTABQgRgBgNgGgAgggeQgKALAAATQAAAUAKAMQALALAVAAQAXAAAKgLQALgMAAgUQAAgTgLgLQgLgMgWABQgVgBgLAMg");
	this.shape_44.setTransform(99.5,9.75);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AAjBKIgkgxIgkAAIAAAxIgQAAIAAiTIAQAAIAABUIAlAAIAjgtIASAAIgqAzIAqA5g");
	this.shape_45.setTransform(87.3,7.825);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgjAvQgOgKAAgTIAPAAIAAABQAAAOAJAFQAIAFAUAAQASAAAHgEQAIgEAAgKQAAgJgGgCQgFgEgOgDIgcgDQgPgCgJgGQgJgGAAgOQAAgKAGgGQAGgHALgFQALgEAPAAQAPABALAEQAMAFAGAIQAGAJAAAMIAAABIgQAAIAAgCQAAgHgDgGQgDgFgIgDQgIgDgNgBQgRAAgIAFQgHAFAAAJQAAAJAFADQAFAEAOACIAZAEQASACAJAGQAJAGAAANQAAALgGAHQgGAHgLADQgLAEgOAAQgYAAgOgKg");
	this.shape_46.setTransform(74.825,9.75);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AggAxQgLgHgEgKQgGgLAAgNIAAg+IAQAAIAAA8QAAARAIAJQAJAJATAAQATAAAKgLQALgLAAgVIAAg0IAPAAIAABrIgOAAIAAgiIgBAAQgCAKgGAIQgFAIgLAFQgJAFgMAAQgRAAgJgGg");
	this.shape_47.setTransform(62.3,9.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AggBEQgMgIgHgMQgGgNAAgRQAAgQAGgMQAHgNAMgHQALgHARAAQASAAAMAJQAMAJADAOIABAAIAAhFIAQAAIAACTIgOAAIAAggIgBAAQgDAQgNAJQgMAJgSAAQgTAAgKgHgAgVgTQgKAFgFAIQgFAJAAAPQAAARAFAIQAFAJAJAFQALAEALAAQANAAAJgFQAKgFAFgJQAGgKgBgMIAAgCQAAgSgLgMQgMgLgTAAQgMAAgJAEg");
	this.shape_48.setTransform(48.55,7.925);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgHA2IAAhrIAPAAIAABrg");
	this.shape_49.setTransform(40.075,9.775);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgHAMIAAgYIAPAAIAAAYg");
	this.shape_50.setTransform(40.075,1.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgsA3IAAhrIAOAAIAAAeIABAAQACgKAFgGQAEgIAIgEQAIgEALgBQAMABAIAFQAIAHAEAHQAEAKAAAJIAAALIgQAAIAAgIQAAgOgGgHQgGgHgPABQgPgBgIAKQgHAKAAATIAAA5g");
	this.shape_51.setTransform(33.025,9.65);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgoAyQgKgIAAgNQAAgKAFgEQAFgHAHgCQAJgEAJgBIAzgEIAAgJQAAgPgHgIQgJgGgRAAQgQgBgKAHQgIAHgBAOIAAABIgQAAIAAgBQAAgMAHgJQAGgJALgGQANgFAPgBQAQAAALAHQAKAEAFALQAFAJAAANIAABCIgOAAIAAgdIgBAAQgFAPgNAJQgOAHgSABQgRgBgJgGgAgKALQgMABgGAEQgGADAAAJQAAAIAGAFQAGADAMAAQANAAAJgDQALgFAGgIQAHgIAAgNIAAgBg");
	this.shape_52.setTransform(20.85,9.75);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AAvBKIAAhDIhdAAIAABDIgQAAIAAiTIAQAAIAABCIBdAAIAAhCIAQAAIAACTg");
	this.shape_53.setTransform(7.425,7.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},48).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},17).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},42).to({state:[]},1).wait(85));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,355.3,41.8);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAALAFQALAGAFAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAAXgHQAAgJgFgEQgFgEgNAAQgMAAgGAFQgEAFgBAHIAuAAIAAAAg");
	this.shape.setTransform(104.225,7.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgYApQgLgEgGgLQgHgLABgPQgBgNAHgKQAGgKALgGQALgGANAAQAQAAAJAFQAMAGAFAJQAHAKAAANIgBAHIhHAAQABAKAEAFQAHAFALAAQAMAAAEgDQAFgDAAgGIAAgCIAbAAIAAACQgBAKgGAHQgEAHgMAFQgLAEgNAAQgOAAgLgFgAAXgHQgBgJgFgEQgEgEgNAAQgMAAgGAFQgDAEgBAIIAtAAIAAAAg");
	this.shape_1.setTransform(93.7,7.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQAQIAAgfIAhAAIAAAfg");
	this.shape_2.setTransform(86.2,10.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAALAFQALAGAFAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAAXgHQAAgJgFgEQgFgEgNAAQgMAAgGAFQgEAFgBAHIAuAAIAAAAg");
	this.shape_3.setTransform(78.725,7.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AggAoQgIgEgEgIQgEgIAAgKIAAg2IAaAAIAAAtQAAALAFAEQAFAFAMAAQANAAAFgFQAFgFAAgLIAAgsIAaAAIAABXIgYAAIAAgbIgCAAQAAAGgFAIQgEAGgIAFQgHAEgLAAQgMAAgIgFg");
	this.shape_4.setTransform(67.875,7.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgZAoQgMgGgGgKQgGgKAAgOQAAgNAGgKQAGgKAMgGQAMgGANAAQAOAAAMAGQAMAGAGAKQAGALAAAMQAAANgGALQgGAKgMAGQgMAGgOAAQgNAAgMgGgAgSgQQgFAGAAAKQAAAMAFAFQAFAFANAAQAOAAAFgFQAFgFAAgMQAAgLgFgFQgGgGgNAAQgMAAgGAGg");
	this.shape_5.setTransform(56.875,7.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAALAFQALAGAFAJQAGAKAAANIAAADIAAAEIhHAAQAAAJAFAGQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAaAAIAAACQAAAJgFAIQgGAHgLAFQgLAEgNAAQgOAAgLgFgAAXgHQgBgJgEgEQgGgEgMAAQgMAAgGAFQgEAFgBAHIAuAAIAAAAg");
	this.shape_6.setTransform(46.225,7.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgoAtIAAhXIAXAAIAAAXIADAAQAAgHAEgFQAEgHAGgCQAEgEAKAAQAKAAAGAEQAHAFACAHQADAGAAAJIAAANIgbAAIAAgIQAAgHgDgDQgDgDgJAAQgHAAgEADQgEAFABAIIAAAyg");
	this.shape_7.setTransform(36.55,7.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AATA7IgWggIgTAAIAAAgIgbAAIAAh1IAbAAIAAA9IATAAIAWgfIAfAAIggApIAgAug");
	this.shape_8.setTransform(26.75,5.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfAlQgMgIAAgPIAAgBIAaAAIAAACQABAGAEACQAEACAKAAQALAAADgCQADgCAAgEQAAgDgCgCQgDgBgHgBIgYgDQgNgCgHgFQgIgGAAgLQABgIAEgGQAEgGAKgEQAKgEAPAAQALAAANAEQAKAEAFAHQAFAHAAALIAAAAIgaAAIAAgBQAAgDgBgDQgBgCgGgCIgLgBQgKAAgDACQgDACAAAEQAAAEACABQACACAKABIASACQASADAGAEQAIAGgBALQAAAJgEAGQgGAGgJADQgKAEgOAAQgVAAgMgJg");
	this.shape_9.setTransform(16.1,7.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMAsIAAhXIAZAAIAABXg");
	this.shape_10.setTransform(9.175,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgMALIAAgUIAZAAIAAAUg");
	this.shape_11.setTransform(9.175,1.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AANA1QgPgBgJgHQgIgIgBgRIAAghIgNAAIAAgVIANAAIAAgSIAaAAIAAASIAcAAIAAAVIgcAAIAAAfQAAAGADADQACABAIAAIAPAAIAAAZg");
	this.shape_12.setTransform(3.45,6.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,12);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1FF8D").s().p("A6LHPIAAudMA0XAAAIrsOdg");
	this.shape.setTransform(167.625,46.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,335.3,92.6);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgxAzQgLgHAAgPQAAgIAFgHQAEgGAIgEQAHgEAOAAIAwgFIAAgFQABgKgHgEQgFgFgOAAQgLAAgHAFQgFADgBAKIAAABIgiAAIAAgBQAAgOAHgLQAIgKAOgGQAOgHASAAQAUAAALAHQANAGAGAKQAHAMAAAPIAABDIghAAIAAgbIgCAAQgDANgNAIQgLAIgSAAQgTAAgLgJgAgMATQgHAAgCACQgEABAAAFQABAEADACQADACAJAAQALAAAIgCQAIgCAEgFQAEgFAAgHg");
	this.shape.setTransform(166.9,37.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgeBKQgOgFgHgKQgHgKAAgPIAiAAQAAAGACAEQADAEAGACQAGABALAAQAJAAAIgCQAGgCADgGQACgFAAgMIAAgZIgBAAQgDALgLAIQgKAJgSgBQgSAAgMgGQgMgHgGgMQgHgMAAgPQAAgPAHgNQAHgMAMgGQAOgHAQAAQARABALAHQANAIACAPIACAAIAAgcIAgAAIAABiQAAAUgIAMQgIANgOAGQgPAHgVAAQgSgBgNgFgAgRguQgHACgDAFQgEAEAAAJQAAAKAEAEQADAFAHADQAHACAKAAQAQAAAIgGQAIgEAAgMIAAgEQAAgHgDgEQgEgGgHgBQgJgCgJAAQgHAAgKACg");
	this.shape_1.setTransform(152.775,39.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgxAzQgKgHAAgPQAAgIAEgHQAFgGAHgEQAIgEANAAIAwgFIAAgFQAAgLgFgDQgGgFgOAAQgLAAgHAFQgFADAAAKIAAABIgjAAIAAgBQAAgOAIgLQAHgKAOgGQANgHATAAQATAAANAHQAMAFAGALQAGAMAAAPIAABDIggAAIAAgbIgCAAQgDAOgMAHQgLAIgUAAQgSAAgLgJgAgNATQgFAAgEACQgDABAAAFQAAAEAEACQAEACAHAAQAMAAAIgCQAIgCAEgFQAEgFAAgHg");
	this.shape_2.setTransform(138.675,37.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAdA7IAAg7QAAgOgGgGQgHgHgQAAQgPAAgHAHQgGAGAAAOIAAA7IgjAAIAAhyIAgAAIAAAjIACAAQACgJAFgJQAGgJAJgFQAJgGAPAAQAQAAAKAHQAKAFAGALQAFALAAAMIAABHg");
	this.shape_3.setTransform(124.975,37.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAdA7IAAg7QAAgOgGgGQgHgHgQAAQgPAAgHAHQgGAGAAAOIAAA7IgjAAIAAhyIAgAAIAAAjIACAAQACgJAFgJQAGgJAJgFQAJgGAPAAQAQAAAKAHQAKAFAGALQAFAKAAANIAABHg");
	this.shape_4.setTransform(110.475,37.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgQBNIAAhyIAhAAIAABygAgQgxIAAgbIAhAAIAAAbg");
	this.shape_5.setTransform(100.575,35.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAeBNIAAg8QAAgOgHgGQgGgFgRAAQgJgBgIAEQgHADgCAFQgDAGAAAJIAAA7IgjAAIAAiZIAjAAIAABKIACAAQABgJAGgKQAFgHAKgGQAJgGAOAAQAQAAAKAHQAKAGAGALQAFALAAAMIAABGg");
	this.shape_6.setTransform(90.625,35.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgpAxQgPgKAAgVIAAgBIAiAAIAAADQAAAHAGADQAGADANgBQAPABADgDQAFgCAAgGQAAgEgEgCQgCgCgLgBIgggFQgRgBgJgHQgKgIAAgOQAAgLAGgIQAGgHANgGQAOgFASAAQATAAAMAFQANAFAIAJQAGAKAAAOIAAAAIgiAAIAAgBQAAgFgCgDQgCgDgGgCQgFgCgKABQgMgBgFADQgEACAAAGQAAAFADACQADACAMABIAYADQAXADAJAHQAKAIAAAOQAAAMgHAHQgHAIgNAFQgMAEgSAAQgcAAgQgLg");
	this.shape_7.setTransform(76.775,37.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgqA1QgMgGgFgLQgEgKgBgNIAAhHIAjAAIAAA7QAAAOAGAHQAHAGAQAAQARAAAGgHQAHgGAAgOIAAg7IAjAAIAAByIghAAIAAgjIgCAAQgBALgFAHQgGAJgJAFQgKAGgPAAQgQAAgKgGg");
	this.shape_8.setTransform(63,37.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgqBHQgMgIgHgNQgGgNAAgTQAAgSAGgMQAHgOAMgHQAMgIARAAQATAAALAKQALAIADAPIACAAIAAhFIAjAAIAACZIggAAIAAggIgCAAQgDARgMAJQgMAIgSAAQgSAAgNgHgAgSgGQgHADgEAFQgDAHAAAJQAAAKADAHQAEAHAHACQAHADALAAQAKAAAIgDQAHgDAEgGQAEgGAAgJIAAgEQAAgOgIgFQgJgGgQAAQgLAAgHADg");
	this.shape_9.setTransform(47.975,35.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgiA0QgPgIgIgMQgIgNAAgTQAAgRAIgOQAIgNAPgHQAPgIATAAQAUAAAOAIQAPAHAIANQAJAPAAAQQAAASgJAOQgIANgPAHQgOAIgUAAQgTAAgPgIgAgYgWQgHAJAAANQAAAOAHAIQAIAIAQAAQARAAAHgIQAHgHAAgPQAAgOgHgIQgHgHgRAAQgQAAgIAHg");
	this.shape_10.setTransform(33.625,37.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AghA0QgPgHgIgNQgJgOAAgSQAAgQAJgPQAIgNAPgHQAPgIASAAQAUAAAPAIQAPAHAIANQAIAOAAARQAAATgIANQgIAMgPAIQgPAIgUAAQgSAAgPgIgAgXgWQgHAIAAAOQAAAPAHAHQAHAIAQAAQARAAAIgIQAHgIAAgOQAAgNgHgJQgIgHgRAAQgQAAgHAHg");
	this.shape_11.setTransform(19.475,37.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgpAxQgQgKAAgVIAAgBIAjAAIAAADQAAAHAGADQAGADANgBQAPABADgDQAFgCAAgGQAAgDgEgDQgDgCgKgBIgggFQgSgBgIgHQgKgIAAgOQAAgLAGgIQAHgIAMgFQAOgFASAAQASAAANAFQAOAFAGAJQAHAKAAAOIAAAAIgiAAIAAgBQAAgFgCgDQgDgDgFgCQgGgCgJABQgMgBgFADQgFACAAAGQAAAEAEADQADACAMABIAXADQAYADAJAHQAKAIAAAOQAAAKgHAJQgHAIgNAFQgMAEgSAAQgdAAgPgLg");
	this.shape_12.setTransform(5.975,37.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdA0QgOgIgHgNQgHgMAAgTQAAgQAHgNQAHgOAOgIQANgHARAAQARAAANAGQANAGAHAMQAHAMAAARIAAAFIgBAEIhjAAQABATAKALQAKAMAWgBQAUABAKgIQAJgHAAgMIAAgBIARAAIAAABQAAALgHAKQgIAJgMAFQgMAFgQAAQgSAAgNgHgAgfghQgKAKgBASIBVAAIAAgDQAAgRgLgKQgLgKgUABQgXAAgJALg");
	this.shape_13.setTransform(336.475,9.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgHBNIAAiZIAPAAIAACZg");
	this.shape_14.setTransform(327.675,7.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgiBIQgOgGgIgKQgHgLgBgOIAAgDIASAAIAAADQAAALAFAHQAHAIAKADQAKADAQAAQAPAAAJgDQAKgEAGgIQAFgHAAgNQAAgNgFgHQgFgIgLgCQgJgEgPAAQgQAAgMADQgLADgJAGIAAgBIAAABIgQgDIAIhQIBwAAIAAAPIhhAAIgHA6IACABIANgIIASgGQAIgCAMAAQATAAALAFQAMAFAIAKQAIALgBAQQAAAPgIAMQgHAMgOAFQgOAGgUAAQgUAAgPgGg");
	this.shape_15.setTransform(318.2,8.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdA0QgNgHgIgOQgHgMAAgTQAAgQAHgNQAIgOAMgIQAOgHASAAQARAAAMAGQAMAGAIAMQAHAMAAARIgBAJIhjAAQABATAKALQAKAMAXgBQATABAKgIQAJgIAAgLIAAgBIARAAIAAABQAAAMgIAJQgGAJgNAFQgMAFgQAAQgSAAgNgHgAgfghQgKAKgBASIBVAAIAAgDQAAgSgLgJQgKgKgVABQgWAAgKALg");
	this.shape_16.setTransform(300.05,9.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHBNIAAiZIAPAAIAACZg");
	this.shape_17.setTransform(291.25,7.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgdA0QgOgIgHgNQgHgMAAgTQAAgQAHgNQAHgOAOgIQANgHARAAQARAAANAGQANAGAHAMQAHAMAAARIAAAFIgBAEIhjAAQABATAKALQAKAMAWgBQAUABAKgIQAJgHAAgMIAAgBIARAAIAAABQAAALgHAKQgIAJgMAFQgMAFgQAAQgSAAgNgHgAgfghQgKAKgBASIBVAAIAAgDQAAgRgLgKQgLgKgUABQgXAAgJALg");
	this.shape_18.setTransform(282.425,9.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AglAxQgPgLAAgTIARAAIAAAAQAAAPAJAFQAJAHAUgBQATABAHgGQAIgEAAgJQAAgJgGgFQgGgEgOgBIgdgFQgQgCgJgGQgJgGAAgOQAAgLAGgHQAGgHALgEQAKgEARAAQAQAAAMAFQALADAHAJQAHAKAAAOIgQAAIAAgBQAAgKgEgFQgDgGgIgDQgIgCgOAAQgSAAgIAEQgIAFAAAKQAAAIAFAEQAGAEAOACIAbAEQATADAIAGQAKAGAAAPQAAAJgGAJQgIAHgKADQgLAEgPAAQgZAAgPgKg");
	this.shape_19.setTransform(269.725,9.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgdA0QgOgIgHgNQgIgMABgTQgBgQAIgNQAGgOAPgIQANgHARAAQARAAANAGQANAGAHAMQAIAMAAARIgCAJIhjAAQABATAKALQAKAMAWgBQAUABAKgIQAKgIAAgLIAAgBIAPAAIAAABQAAAMgGAJQgHAIgNAGQgMAFgRAAQgQAAgOgHgAgfghQgKAKgBASIBVAAIAAgDQAAgRgLgKQgLgKgUABQgXAAgJALg");
	this.shape_20.setTransform(257,9.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("ABSA6IAAg/QAAgSgJgKQgJgJgRAAQgVAAgJAMQgIALgBATIAAA6IgPAAIAAg/QAAgSgIgKQgJgJgRAAQgVAAgJAMQgIALgBATIAAA6IgQAAIAAhxIAOAAIAAAjIABAAQACgLAFgHQAFgJAKgFQAJgFAOAAQAPAAAJAHQAKAGAFALQACAHABAHIABAAQACgJAFgKQAGgIAJgGQAJgFAOAAQAQAAAJAGQALAHAFALQAEAKAAAQIAABBg");
	this.shape_21.setTransform(239.3,9.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHBNIAAhxIAPAAIAABxgAgHgyIAAgaIAPAAIAAAag");
	this.shape_22.setTransform(226.025,7.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AglAxQgPgKAAgUIARAAIAAAAQgBAPAJAFQALAHASgBQAVABAGgGQAIgEAAgJQAAgJgGgFQgGgEgOgBIgdgFQgRgCgIgGQgJgGAAgOQAAgLAGgHQAGgHAMgEQAKgEAQAAQAPAAANAFQALAEAIAIQAGAJAAAPIgQAAIAAgBQgBgKgDgFQgCgGgKgDQgHgCgOAAQgTAAgHAEQgIAEAAALQAAAJAGADQAFAEAOACIAbAEQASADAKAGQAJAGAAAPQAAAKgHAIQgHAHgLADQgKAEgQAAQgZAAgOgKg");
	this.shape_23.setTransform(217.75,9.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgdA0QgOgHgHgOQgHgNAAgSQAAgQAHgNQAHgOAOgIQANgHARAAQARAAANAGQAMAGAIAMQAHAMAAARIgBAJIhjAAQABAUAJAKQALAMAWgBQAUABAKgIQAJgHAAgMIAAgBIARAAIAAABQAAAMgIAJQgGAJgNAFQgMAFgRAAQgRAAgNgHgAggghQgJAKgBASIBVAAIAAgDQAAgSgLgJQgLgKgUABQgXAAgKALg");
	this.shape_24.setTransform(205.025,9.95);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgiBHQgNgIgGgNQgHgNAAgSQAAgSAHgLQAHgOAMgHQAMgIARAAQAUAAAMAKQANAKADAOIABAAIAAhIIARAAIAACZIgPAAIAAgiIgBAAQgEARgNAKQgNAJgSAAQgSAAgNgHgAgWgUQgLAFgFAJQgFAJAAAQQAAAQAFAKQAFAKALAEQAKAEAMAAQAOAAAJgFQAJgEAHgKQAFgKAAgLIAAgGQAAgSgMgLQgMgMgUAAQgMAAgKAEg");
	this.shape_25.setTransform(186.725,8.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgiAzQgLgHgFgLQgFgMAAgNIAAhBIAQAAIAAA/QAAASAJAKQAJAKAUAAQAUAAAKgNQALgLAAgUIAAg5IAQAAIAABwIgOAAIAAgjIgBAAQgDALgFAHQgHAKgKAFQgKAFgNAAQgQAAgLgHg");
	this.shape_26.setTransform(173.025,10.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAQBGQgQAAgKgIQgKgHAAgVIAAg+IgUAAIAAgOIAUAAIAAgbIARAAIAAAbIAsAAIAAAOIgsAAIAAA/QAAANAFADQAFAEANAAIAVAAIAAAPg");
	this.shape_27.setTransform(161.575,8.575);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AglAxQgPgKAAgUIAQAAIAAAAQAAAPAKAFQAJAHAUgBQATABAHgGQAIgEAAgJQAAgJgGgFQgFgDgPgCIgegFQgQgCgIgGQgJgGAAgOQAAgLAGgHQAGgHAMgEQAKgEARAAQAOAAAMAFQANAEAGAIQAHAJAAAPIgQAAIAAgBQAAgIgDgHQgEgGgJgDQgHgCgOAAQgSAAgIAEQgIAEAAALQAAAIAGAEQAFAEAOACIAbAEQASADAKAGQAJAGAAAPQAAAKgHAIQgHAHgLADQgKAEgQAAQgYAAgPgKg");
	this.shape_28.setTransform(151.25,9.95);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgHBNIAAhxIAPAAIAABxgAgHgyIAAgaIAPAAIAAAag");
	this.shape_29.setTransform(142.975,7.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAoA6IAAg/QgBgRgIgKQgJgKgUAAQgUAAgLAMQgJALgBATIAAA6IgQAAIAAhxIAPAAIAAAkIABAAQACgLAGgHQAFgIALgHQAJgFAOAAQAQAAAKAHQAMAHAEALQAGAMAAANIAABBg");
	this.shape_30.setTransform(133.9,9.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAoA6IAAg/QAAgRgJgKQgJgKgUAAQgTAAgLAMQgKALAAATIAAA6IgRAAIAAhxIAPAAIAAAkIABAAQACgLAGgHQAFgIALgHQAJgFAOAAQARAAAKAHQALAHAFALQAFAKAAAPIAABBg");
	this.shape_31.setTransform(120,9.825);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgHBNIAAhxIAPAAIAABxgAgHgyIAAgaIAPAAIAAAag");
	this.shape_32.setTransform(110.85,7.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAkBNIglgzIglAAIAAAzIgRAAIAAiZIARAAIAABXIAlAAIAlgvIAUAAIgsA2IAsA7g");
	this.shape_33.setTransform(102.85,7.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AghAnIAAgEQAAgMAGgIQAHgGAKgEIAdgKQAEgDAAgGQAAgGgEgEQgEgCgNAAQgMgBgGAEQgGAEAAAJIAAACIgNAAIAAgCQAAgHAEgHQAFgGAIgEQAIgEAMAAQARAAAIAGQAJAIAAAKQAAAKgHAEQgGAEgNAEIgQAFIgLAHQgDADAAAGIA4gBIAAALg");
	this.shape_34.setTransform(87.625,3.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("ABRA6IAAg/QAAgTgIgJQgIgJgTAAQgUAAgJAMQgIALgBATIAAA6IgQAAIAAg/QABgTgJgJQgIgJgSAAQgVAAgJAMQgIALAAATIAAA6IgRAAIAAhxIAPAAIAAAjIABAAQACgJAFgJQAEgIAKgGQAJgFAPAAQAPAAAKAHQAIAFAFAMIAEAOIABAAQABgJAGgKQAFgHAJgHQAKgFAPAAQAOAAALAGQAJAHAFALQAGAMAAAOIAABBg");
	this.shape_35.setTransform(72.4,9.825);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgkBGQgSgKgHgSQgKgSABgYQgBgYAKgSQAIgSARgJQAPgJAVAAQAWAAAQAJQAQAJAJASQAJATAAAXQAAAYgJASQgIASgRAKQgQAJgWAAQgVAAgPgJgAgdg4QgMAHgGAOQgGAPAAAUQAAAWAGAOQAGAOAMAHQANAHAQAAQASAAAMgHQAMgHAGgOQAGgQABgUQgBgTgGgQQgGgOgMgHQgLgHgTAAQgSAAgLAHg");
	this.shape_36.setTransform(53.3,7.925);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AglBGQgQgKgJgSQgIgRAAgZQAAgZAIgRQAKgSAPgJQAQgJAVAAQAWAAAQAJQAPAJAKASQAIATAAAXQAAAYgIASQgJASgQAKQgQAJgWAAQgVAAgQgJgAgdg4QgMAHgGAOQgGAPAAAUQAAAWAGAOQAGAOAMAHQANAHAQAAQARAAANgHQAMgHAGgOQAGgOAAgWQAAgVgGgOQgGgOgMgHQgLgHgTAAQgSAAgLAHg");
	this.shape_37.setTransform(37.425,7.925);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AglBGQgQgKgJgSQgIgRAAgZQAAgZAIgRQAKgSAPgJQAQgJAVAAQAWAAAQAJQAPAJAKASQAIATAAAXQAAAYgIASQgJASgQAKQgQAJgWAAQgVAAgQgJgAgdg4QgMAHgGAOQgGAPAAAUQAAAWAGAOQAGAOAMAHQANAHAQAAQARAAANgHQALgHAHgOQAGgOAAgWQAAgUgGgPQgHgOgLgHQgLgHgTAAQgSAAgLAHg");
	this.shape_38.setTransform(21.525,7.925);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("Ag8BOIAAgLQAAgPAEgKQAEgLAJgGQAKgIAPgGIAigLQAKgEAHgEQAGgEAEgGQACgHAAgHQAAgKgFgGQgEgHgKgEQgKgDgOAAQgQAAgKAFQgKADgGAJQgEAIAAALIAAADIgRAAIAAgCQABgOAGgMQAGgLAOgIQAOgHAWAAQAWAAAMAGQAOAGAFALQAHAKAAAMQgBAMgEAJQgGAJgIAEQgJAGgOAGIgeAKQgNAFgIAFQgHAFgCAHQgDAIAAAKIBpgBIAAAPg");
	this.shape_39.setTransform(6.6,7.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,342.3,47.4);


(lib.HTML4htmlaicopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// HTML4_html_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgiA6QgQgGgJgQQgJgNAAgXQAAgUAJgOQAJgOAPgIQAQgIAUAAQAUAAAPAHQAQAHAIANQAJAOAAAUIAAAEIgBAGIhlAAQAAAOAHAHQAIAHASAAQARAAAGgEQAHgEAAgJIAAgCIAmAAIAAADQAAANgJALQgIAKgPAHQgPAFgUAAQgVAAgOgHgAAhgLQgBgMgHgFQgJgHgQAAQgSAAgIAHQgFAGgCALIBCAAIAAAAg");
	this.shape.setTransform(230.375,29.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSBUIAAinIAlAAIAACng");
	this.shape_1.setTransform(220.025,26.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgjA6QgQgHgIgPQgJgOAAgWQAAgSAJgQQAIgNAQgJQAQgIATAAQAUAAARAHQAOAHAKANQAIAOAAAUIgBAKIhlAAQABAOAGAHQAJAHARAAQASAAAGgEQAGgEAAgJIAAgCIAlAAIAAADQAAAOgHAKQgIAKgQAHQgPAFgUAAQgVAAgPgHgAAhgLQgCgMgGgFQgIgHgRAAQgSAAgIAHQgFAHgCAKIBCAAIAAAAg");
	this.shape_2.setTransform(209.65,29.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgtBNQgOgHgHgQQgHgPAAgTQAAgTAHgPQAHgOANgIQANgIATAAQAVAAAMAKQAMAKADAQIACAAIAAhMIAmAAIAACmIgjAAIAAgiIgCAAQgEASgMAKQgNAJgUAAQgUAAgNgIgAgTgHQgIACgEAHQgEAGAAAMQAAALAEAHQAEAHAIADQAHADAMAAQAMAAAIgDQAHgCAFgIQAEgGAAgLIAAgCQAAgRgJgFQgKgHgRAAQgMAAgHADg");
	this.shape_3.setTransform(193.775,27.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgiA6QgQgGgJgQQgJgNAAgXQAAgUAJgOQAJgOAPgIQAQgIAUAAQAUAAAPAHQAQAHAIANQAJAOAAAUIAAAEIgBAGIhlAAQAAAOAHAHQAIAHASAAQARAAAGgEQAHgEAAgJIAAgCIAmAAIAAADQAAANgJALQgIAKgPAHQgPAFgUAAQgVAAgOgHgAAhgLQgBgMgHgFQgJgHgQAAQgSAAgIAHQgFAGgCALIBCAAIAAAAg");
	this.shape_4.setTransform(178.375,29.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag6BAIAAh8IAjAAIAAAhIACAAQABgKAGgIQAFgJAJgEQAHgFANAAQAOAAAJAGQAIAGAEAKQAEAKAAAMIAAAUIglAAIAAgMQAAgLgFgEQgEgFgMAAQgLAAgGAGQgFAGAAALIAABIg");
	this.shape_5.setTransform(164.575,28.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgiA6QgQgGgJgQQgJgNAAgXQAAgUAJgOQAJgOAPgIQAQgIAUAAQAUAAAPAHQAQAHAIANQAJAOAAAUIAAAEIgBAGIhlAAQAAAOAHAHQAIAHASAAQARAAAGgEQAHgEAAgJIAAgCIAmAAIAAADQAAANgJALQgIAKgPAHQgPAFgUAAQgVAAgOgHgAAhgLQgBgMgHgFQgJgHgQAAQgSAAgIAHQgFAGgCALIBCAAIAAAAg");
	this.shape_6.setTransform(150.175,29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhIBVIAAinIAiAAIAAAiIADAAQACgRANgKQANgJAUAAQAVAAAMAIQAOAIAGAOQAIAQAAATQAAAUgIANQgGAQgNAHQgNAIgTAAQgWAAgLgKQgNgKgCgQIgCAAIAABMgAgagqQgJAHAAAQIAAACQAAALAEAGQAEAGAJACQAIADALAAQALAAAJgDQAHgDAEgGQAEgHAAgLQAAgNgEgFQgEgHgHgDQgJgCgLAAQgTgBgIAIg");
	this.shape_7.setTransform(134.75,31.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgiA6QgRgHgIgPQgJgOAAgWQAAgSAJgQQAIgNAQgJQAPgIAVAAQATAAARAHQAOAHAKANQAIAOAAAUIgBAKIhlAAQABAOAHAHQAHAHASAAQASAAAFgEQAHgEAAgJIAAgCIAlAAIAAADQAAAOgIAKQgIAKgPAHQgPAFgUAAQgVAAgOgHgAAggLQAAgMgHgFQgIgHgRAAQgSAAgHAHQgHAHgBAKIBBAAIAAAAg");
	this.shape_8.setTransform(115.05,29.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAgBAIAAhBQAAgPgHgGQgIgHgRAAQgRAAgHAHQgHAHAAAQIAAA/IglAAIAAh8IAiAAIAAAmIADAAQABgKAGgKQAGgKAKgFQALgGAQAAQARAAALAHQALAGAGAMQAFAMAAANIAABNg");
	this.shape_9.setTransform(99.725,28.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgSBUIAAinIAlAAIAACng");
	this.shape_10.setTransform(88.925,26.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Ag1A4QgMgJABgPQgBgJAFgHQAEgHAKgEQAJgFANAAIA0gFIAAgGQABgMgHgEQgGgEgOAAQgNAAgHAEQgGAFgBAKIAAABIglAAIAAAAQAAgQAIgMQAIgMAPgGQAPgHAUAAQAVAAANAHQAOAGAHANQAGALAAARIAABIIgjAAIAAgcIgCAAQgEAOgNAJQgLAIgWAAQgTAAgMgJgAgOAUIgKADQgDACAAAEQAAAFAEACQADACAKABQANAAAIgDQAJgCAEgGQAEgGAAgHg");
	this.shape_11.setTransform(78.6,29.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag1A4QgLgJAAgPQAAgJAEgHQAEgHAKgEQAKgFAMAAIA0gFIAAgGQAAgMgFgEQgHgEgPAAQgNAAgGAEQgHAFAAAKIAAABIglAAIAAAAQAAgQAIgMQAIgMAQgGQAOgHAUAAQAVAAANAHQAOAGAHANQAHALgBARIAABIIgiAAIAAgcIgDAAQgEAOgNAJQgLAIgVAAQgUAAgMgJgAgOAUIgKADQgDACAAAEQAAAFAEACQADACAKABQANAAAHgDQAKgCAEgGQAEgGAAgHg");
	this.shape_12.setTransform(64.05,29.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgiA6QgQgGgJgQQgJgNAAgXQAAgUAJgOQAJgOAPgIQAQgIAUAAQAUAAAPAHQAQAHAIANQAJAOAAAUIAAAEIgBAGIhlAAQABAPAGAGQAIAHASAAQARAAAGgEQAHgEAAgJIAAgCIAmAAIAAADQAAANgJALQgIAKgPAHQgPAFgUAAQgVAAgOgHgAAhgLQgBgMgHgFQgJgHgQAAQgSAAgIAHQgFAHgCAKIBCAAIAAAAg");
	this.shape_13.setTransform(49.475,29.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgtBNQgOgHgHgQQgHgNAAgVQAAgUAHgOQAHgOANgIQANgIATAAQAUAAANAKQAMAKADAQIACAAIAAhMIAmAAIAACmIgjAAIAAgiIgCAAQgEASgMAKQgNAJgUAAQgUAAgNgIgAgUgHQgHADgEAGQgEAFAAANQAAALAEAHQAEAHAHADQAJADALAAQAMAAAHgDQAIgCAFgIQAEgGAAgLIAAgCQAAgQgJgGQgKgHgRAAQgLAAgJADg");
	this.shape_14.setTransform(33.625,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgSBUIAAinIAlAAIAACng");
	this.shape_15.setTransform(22.825,26.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E1FF8D").s().p("AwGETQhyAAhRhQQhQhRAAhyQAAhxBQhRQBRhQByAAMAgNAAAQByAABRBQQBQBRAABxQAAByhQBRQhRBQhyAAg");
	this.shape_16.setTransform(130.6,27.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,261.2,55);


// stage content:
(lib.RECOVER_HTMLtiskre_lühem = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYApQgLgEgGgLQgHgLABgPQgBgNAHgKQAGgKALgGQALgGANAAQAPAAAKAFQAMAGAGAJQAFAKABANIgBAHIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAbAAIAAACQgBAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgFgEQgEgEgNAAQgNAAgFAFg");
	this.shape.setTransform(150.55,382.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAAKAFQAMAGAFAJQAGAKAAANIAAADIAAAEIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgEAAgFIAAgCIAaAAIAAACQAAAJgFAIQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgGgEgMAAQgMAAgGAFg");
	this.shape_1.setTransform(140.025,382.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQAPIAAgdIAhAAIAAAdg");
	this.shape_2.setTransform(132.5,385.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYApQgKgEgIgLQgFgLAAgPQAAgNAFgKQAHgKALgGQALgGANAAQAPAAALAFQALAGAGAJQAFAKAAANIgBAHIhGAAQAAAKAFAFQAGAFAMAAQALAAAGgDQAEgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgKAFQgLAEgOAAQgPAAgKgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgFgEgNAAQgMAAgGAFg");
	this.shape_3.setTransform(125.05,382.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AggAoQgIgEgEgIQgEgJAAgJIAAg2IAaAAIAAAtQAAALAFAEQAFAFAMAAQANAAAFgFQAFgFAAgKIAAgtIAaAAIAABXIgYAAIAAgbIgCAAQAAAIgFAGQgDAGgIAFQgIAEgLAAQgMAAgIgFg");
	this.shape_4.setTransform(114.175,382.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgZAoQgMgGgGgKQgGgKAAgOQAAgNAGgKQAGgKAMgGQAMgGANAAQAOAAAMAGQAMAGAGAKQAGAKAAANQAAAOgGAKQgGAKgMAGQgMAGgOAAQgNAAgMgGgAgSgQQgFAGAAAKQAAALAFAGQAFAFANAAQAOAAAFgFQAFgGAAgLQAAgKgFgGQgGgGgNAAQgMAAgGAGg");
	this.shape_5.setTransform(103.175,382.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQALgGAOAAQAPAAAKAFQAMAGAEAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAFgDQAEgDAAgGIAAgCIAbAAIAAACQAAAKgGAHQgGAHgKAFQgLAEgOAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQAAgJgFgEQgFgEgNAAQgMAAgGAFg");
	this.shape_6.setTransform(92.525,382.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgpAtIAAhXIAZAAIAAAXIABAAQACgIAEgEQADgGAGgDQAEgEAKAAQAJAAAHAEQAGAFADAGQADAJAAAHIAAAOIgaAAIAAgJQgBgGgDgEQgDgDgIAAQgIAAgDAEQgEADAAAIIAAAzg");
	this.shape_7.setTransform(82.85,382.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AASA7IgUggIgUAAIAAAgIgbAAIAAh1IAbAAIAAA+IAUAAIAVggIAfAAIggAqIAgAtg");
	this.shape_8.setTransform(73.05,381.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfAlQgMgIAAgPIAAgBIAaAAIAAACQAAAGAFACQADACALAAQAKAAAEgCQAEgCAAgEQAAgDgDgCQgDgCgIAAIgYgDQgNgCgHgFQgGgFgBgMQAAgIAFgGQAEgGAKgEQALgEANAAQAMAAAMAEQAKADAGAIQAFAIAAAKIAAAAIgbAAIAAgBQABgDgCgDQgBgCgFgCIgLgBQgKAAgDACQgEACAAAEQABADACACQADACAJABIARACQASACAHAFQAIAGgBALQABAIgGAHQgGAGgJADQgJAEgOAAQgUAAgNgJg");
	this.shape_9.setTransform(62.45,382.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMA7IAAhXIAZAAIAABXgAgMglIAAgVIAZAAIAAAVg");
	this.shape_10.setTransform(55.5,381.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAMA0QgOAAgJgHQgJgIAAgQIAAgiIgNAAIAAgVIANAAIAAgRIAaAAIAAARIAcAAIAAAVIgcAAIAAAfQAAAHADACQACACAHAAIAQAAIAAAXg");
	this.shape_11.setTransform(49.775,381.925);

	this.instance = new lib.Tween14("synched",0);
	this.instance.setTransform(100.85,381.35);
	this.instance._off = true;

	this.instance_1 = new lib.Tween15("synched",0);
	this.instance_1.setTransform(-101.05,381.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},6).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},5).to({state:[{t:this.instance}]},122).to({state:[{t:this.instance_1}]},9).to({state:[]},25).wait(27));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(133).to({_off:false},0).to({_off:true,x:-101.05},9).wait(52));

	// Layer_10
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E1FF8D").s().p("AoLC1QhLgBg0g0Qg1g1AAhLQAAhJA1g1QA0g1BLAAIQXAAQBLAAA1A1QA0A1AABJQAABLg0A1Qg1A0hLABg");
	this.shape_12.setTransform(101.4,381.45);

	this.instance_2 = new lib.Tween16("synched",0);
	this.instance_2.setTransform(101.4,381.45);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween17("synched",0);
	this.instance_3.setTransform(-100.55,381.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_12}]},6).to({state:[{t:this.shape_12}]},5).to({state:[{t:this.instance_2}]},122).to({state:[{t:this.instance_3}]},9).to({state:[]},25).wait(27));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(133).to({_off:false},0).to({_off:true,x:-100.55},9).wait(52));

	// Layer_3
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#202529").s().p("AgQgIIAAAoIgKAAIAAhAIAqApIAAgoIALAAIAABAg");
	this.shape_13.setTransform(382.15,369.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#202529").s().p("AgMAeQgHgDgDgEQgEgDgDgHQgDgHAAgGQAAgFADgHIAHgKIAKgHQAHgDAFAAQAGAAAHADQAHADADAEQAFAFACAFQADAFAAAHQAAAIgDAFQgCAFgFAFQgFAFgFACQgFACgIAAIAAABQgFAAgHgDgAgIgUQgEABgDADQgDADgBAFQgCAEAAAEQAAAFACADQABAFADADIAHAFIAIABIAAABQAEAAAFgCQADgBAEgEIAFgHIABgJIgBgIIgFgIQgDgDgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_14.setTransform(371.475,369.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#202529").s().p("AgSAgIAAg/IALAAIAAA0IAaAAIAAALg");
	this.shape_15.setTransform(362.675,369.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#202529").s().p("AAAAAIAAAAIAAAAg");
	this.shape_16.setTransform(356.3875,372.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#202529").s().p("AAUAhIgHgPIgZAAIgHAPIgLAAIAehAIAfBAgAgIAIIARAAIgJgSg");
	this.shape_17.setTransform(353.275,369.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#202529").s().p("AgcgfIALAAIARAnIASgnIALAAIgdA/g");
	this.shape_18.setTransform(344.65,369.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#202529").s().p("AAAAAIAAAAIAAAAgAAAAAIAAAAIAAAAIAAAAg");
	this.shape_19.setTransform(339.1625,372.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#202529").s().p("AAUAhIgHgPIgZAAIgHAPIgLAAIAehAIAfBAgAgIAIIARAAIgJgSg");
	this.shape_20.setTransform(336.025,369.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#202529").s().p("AgpgkIBTAAIgGALIg7AAIAdAzIgGALg");
	this.shape_21.setTransform(320.775,374.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#202529").s().p("AgFAaIAdgzIg7AAIgGgLIBTAAIgqBJg");
	this.shape_22.setTransform(310.775,374.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#202529").s().p("AgogjIAMAAIAcAxIAdgxIAMAAIgpBGg");
	this.shape_23.setTransform(315.8,365.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D1D1B").s().p("AgSAhIAAhBIAlAAIAAALIgaAAIAAAQIAVAAIAAAKIgVAAIAAARIAaAAIAAALg");
	this.shape_24.setTransform(382.35,394.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D1D1B").s().p("AgSAaQgIgHAAgMIAAgnIALAAIAAAnQAAAQAPAAQAQAAAAgQIAAgnIAKAAIAAAnQAAAMgHAHQgHAHgMAAQgLAAgHgHg");
	this.shape_25.setTransform(373.3,394.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D1D1B").s().p("AgXAhQgKgKAAgPQAAgNAKgKQAKgJANAAQAOAAAKAJQAKAKAAANQAAAPgKAKQgKAJgOAAQgNAAgKgJgAgPgHQgHAHAAAIQAAAKAHAHQAGAHAJAAQAKAAAGgHQAHgHAAgKQAAgJgHgGQgGgHgKAAQgIAAgHAHgAAAggIgEgCQgEAAAAAEIgIAAIABgCQABgJAJAAQADAAADACIAFACQADAAABgEIAHAAIAAACQgCAJgIAAQgDAAgEgCg");
	this.shape_26.setTransform(363.175,393.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D1D1B").s().p("AgTAhIAAhBIAnAAIAAALIgcAAIAAAQIAWAAIAAAKIgWAAIAAARIAcAAIAAALg");
	this.shape_27.setTransform(354.025,394.575);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D1D1B").s().p("AAMAhIgTgcIgGAAIAAAcIgLAAIAAhBIAVAAQAIAAAHAFQAFAGABAIQAAANgOAEIAVAdgAgNgDIAJAAQAKAAAAgKQAAgJgKAAIgJAAg");
	this.shape_28.setTransform(345.7,394.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D1D1B").s().p("AANAhIgcgfIAAAfIgLAAIAAhBIALAAIAAAgIAbggIAMAAIgbAgIAeAhg");
	this.shape_29.setTransform(336.7,394.575);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1D1D1B").s().p("AgVAWIAIgGQAGAHAIAAQAJAAABgHQAAgGgKgFIgEgCQgPgFAAgNQAAgIAGgFQAFgFAIAAQAMAAAGAJIgHAHQgEgFgHAAQgIAAAAAHQAAAGAJAEIAEACQAPAGABAMQgBAIgFAGQgGAFgJAAQgPAAgHgMg");
	this.shape_30.setTransform(327.7,394.575);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1D1D1B").s().p("AgEAhIAAhBIAKAAIAABBg");
	this.shape_31.setTransform(321,394.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D1D1B").s().p("AgEAhIAAg2IgRAAIAAgLIArAAIAAALIgRAAIAAA2g");
	this.shape_32.setTransform(314.225,394.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1D1D1B").s().p("AgpgjIBTAAIgGAKIg7AAIAdAzIgGAKg");
	this.shape_33.setTransform(299.725,399.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1D1D1B").s().p("AgFAaIAcgzIg6AAIgGgKIBTAAIgpBHg");
	this.shape_34.setTransform(289.8,399.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1D1D1B").s().p("AgogiIANAAIAbAwIAdgwIAMAAIgpBFg");
	this.shape_35.setTransform(294.775,391.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]}).wait(194));

	// logode_all
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#E1FF8D").s().p("A8IHPILsudMAslAAAIAAOdg");
	this.shape_36.setTransform(389.9,389.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_36).wait(194));

	// tekst
	this.instance_4 = new lib.Symbol1("synched",0);
	this.instance_4.setTransform(202.35,59.6,1,1,0,0,0,171.2,23.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({startPosition:0},0).to({alpha:0},22,cjs.Ease.quartOut).to({_off:true},1).wait(137));

	// Symbol_12
	this.instance_5 = new lib.Symbol12("synched",0);
	this.instance_5.setTransform(203.5,63.15,1,1,0,0,0,177.7,20.9);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(49).to({startPosition:49},0).to({alpha:1,startPosition:66},17).wait(32).to({startPosition:98},0).to({alpha:0,startPosition:108},10).to({_off:true},1).wait(85));

	// kaldüleval
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#E1FF8D").s().p("A6LHPIAAudMA0XAAAIrsOdg");
	this.shape_37.setTransform(127.175,73.25);

	this.instance_6 = new lib.Symbol3("synched",0);
	this.instance_6.setTransform(127.15,73.25,1,1,0,0,0,167.6,46.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37}]}).to({state:[{t:this.instance_6}]},40).to({state:[{t:this.instance_6}]},63).to({state:[{t:this.instance_6}]},12).to({state:[]},1).wait(78));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(40).to({_off:false},0).wait(63).to({startPosition:0},0).to({y:36.45},12).to({_off:true},1).wait(78));

	// ristkülik_üleval
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#E1FF8D").s().p("A/dI1IAAxpMA+7AAAIAARpg");
	this.shape_38.setTransform(177.525,26.175);

	this.instance_7 = new lib.Tween5("synched",0);
	this.instance_7.setTransform(177.5,26);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween6("synched",0);
	this.instance_8.setTransform(630.5,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38}]}).to({state:[{t:this.instance_7}]},116).to({state:[{t:this.instance_8}]},13).to({state:[]},3).wait(62));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(116).to({_off:false},0).to({_off:true,x:630.5},13).wait(65));

	// vertikaalne
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#E1FF8D").s().p("EgI/AoWMAAAhQrIR/AAMAAABQrg");
	this.shape_39.setTransform(436.075,236.775);

	this.instance_9 = new lib.Tween7("synched",0);
	this.instance_9.setTransform(436.05,236.75);
	this.instance_9._off = true;

	this.instance_10 = new lib.Tween8("synched",0);
	this.instance_10.setTransform(436.05,620.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39}]}).to({state:[{t:this.instance_9}]},127).to({state:[{t:this.instance_10}]},12).to({state:[]},1).wait(54));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(127).to({_off:false},0).to({_off:true,y:620.4},12).wait(55));

	// Symbol_13
	this.instance_11 = new lib.Symbol13("synched",0);
	this.instance_11.setTransform(156.5,258.2,1,1,0,0,0,343.5,193.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(35).to({startPosition:35},0).to({alpha:0,startPosition:60},25).wait(134));

	// kauss
	this.instance_12 = new lib.Kausspsd();
	this.instance_12.setTransform(324.2,96.8,0.1374,0.1374);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},103).wait(91));

	// Symbol_14
	this.instance_13 = new lib.Symbol14("synched",0);
	this.instance_13.setTransform(222.5,283.9,0.8204,0.8203,0,0,0,309,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(96).to({startPosition:95},0).to({alpha:0,startPosition:127},31).wait(67));

	// ideaalkoos
	this.instance_14 = new lib.HTML4htmlaicopy("synched",0);
	this.instance_14.setTransform(-134.4,51.35,1,1,0,0,0,130.6,27.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(119).to({y:50.15},0).to({x:162.05,y:51.35},16).wait(59));

	// veeb
	this.instance_15 = new lib.Symbol8("synched",0);
	this.instance_15.setTransform(88.05,392.15,1,1,0,0,0,54.5,6);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(143).to({_off:false},0).to({alpha:1},13).wait(38));

	// alumine_rsitk
	this.instance_16 = new lib.Tween9("synched",0);
	this.instance_16.setTransform(470.15,419.8);
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween10("synched",0);
	this.instance_17.setTransform(185.35,420);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},132).to({state:[{t:this.instance_17}]},15).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(132).to({_off:false},0).to({_off:true,x:185.35,y:420},15).wait(47));

	// Layer_2
	this.instance_18 = new lib.peremetsas_alt();
	this.instance_18.setTransform(-16,-32,0.9822,0.9822);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgYApQgLgEgGgLQgHgLABgPQgBgNAHgKQAGgKALgGQALgGANAAQAPAAAKAFQAMAGAGAJQAFAKABANIgBAHIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgDAAgGIAAgCIAbAAIAAACQgBAKgFAHQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgFgEQgEgEgNAAQgNAAgFAFg");
	this.shape_40.setTransform(150.55,382.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQAMgGAMAAQAPAAAKAFQAMAGAFAJQAGAKAAANIAAADIAAAEIhHAAQAAAKAFAFQAGAFAMAAQAMAAAEgDQAFgEAAgFIAAgCIAaAAIAAACQAAAJgFAIQgGAHgLAFQgLAEgNAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgGgEgMAAQgMAAgGAFg");
	this.shape_41.setTransform(140.025,382.775);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgQAPIAAgdIAhAAIAAAdg");
	this.shape_42.setTransform(132.5,385.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgYApQgKgEgIgLQgFgLAAgPQAAgNAFgKQAHgKALgGQALgGANAAQAPAAALAFQALAGAGAJQAFAKAAANIgBAHIhGAAQAAAKAFAFQAGAFAMAAQALAAAGgDQAEgDAAgGIAAgCIAaAAIAAACQAAAKgFAHQgGAHgKAFQgLAEgOAAQgPAAgKgFgAgSgTQgEAEgBAIIAuAAQgBgJgEgEQgFgEgNAAQgMAAgGAFg");
	this.shape_43.setTransform(125.05,382.775);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AggAoQgIgEgEgIQgEgJAAgJIAAg2IAaAAIAAAtQAAALAFAEQAFAFAMAAQANAAAFgFQAFgFAAgKIAAgtIAaAAIAABXIgYAAIAAgbIgCAAQAAAIgFAGQgDAGgIAFQgIAEgLAAQgMAAgIgFg");
	this.shape_44.setTransform(114.175,382.875);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgZAoQgMgGgGgKQgGgKAAgOQAAgNAGgKQAGgKAMgGQAMgGANAAQAOAAAMAGQAMAGAGAKQAGAKAAANQAAAOgGAKQgGAKgMAGQgMAGgOAAQgNAAgMgGgAgSgQQgFAGAAAKQAAALAFAGQAFAFANAAQAOAAAFgFQAFgGAAgLQAAgKgFgGQgGgGgNAAQgMAAgGAGg");
	this.shape_45.setTransform(103.175,382.775);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgYApQgLgFgGgKQgGgLAAgPQAAgNAGgKQAFgKAMgGQALgGAOAAQAPAAAKAFQAMAGAEAJQAGAKAAANIAAADIAAAEIhHAAQABAKAEAFQAGAFAMAAQAMAAAFgDQAEgDAAgGIAAgCIAbAAIAAACQAAAKgGAHQgGAHgKAFQgLAEgOAAQgOAAgLgFgAgSgTQgEAEgBAIIAuAAQAAgJgFgEQgFgEgNAAQgMAAgGAFg");
	this.shape_46.setTransform(92.525,382.775);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgpAtIAAhXIAZAAIAAAXIABAAQACgIAEgEQADgGAGgDQAEgEAKAAQAJAAAHAEQAGAFADAGQADAJAAAHIAAAOIgaAAIAAgJQgBgGgDgEQgDgDgIAAQgIAAgDAEQgEADAAAIIAAAzg");
	this.shape_47.setTransform(82.85,382.675);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AASA7IgUggIgUAAIAAAgIgbAAIAAh1IAbAAIAAA+IAUAAIAVggIAfAAIggAqIAgAtg");
	this.shape_48.setTransform(73.05,381.275);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgfAlQgMgIAAgPIAAgBIAaAAIAAACQAAAGAFACQADACALAAQAKAAAEgCQAEgCAAgEQAAgDgDgCQgDgCgIAAIgYgDQgNgCgHgFQgGgFgBgMQAAgIAFgGQAEgGAKgEQALgEANAAQAMAAAMAEQAKADAGAIQAFAIAAAKIAAAAIgbAAIAAgBQABgDgCgDQgBgCgFgCIgLgBQgKAAgDACQgEACAAAEQABADACACQADACAJABIARACQASACAHAFQAIAGgBALQABAIgGAHQgGAGgJADQgJAEgOAAQgUAAgNgJg");
	this.shape_49.setTransform(62.45,382.775);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgMA7IAAhXIAZAAIAABXgAgMglIAAgVIAZAAIAAAVg");
	this.shape_50.setTransform(55.5,381.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAMA0QgOAAgJgHQgJgIAAgQIAAgiIgNAAIAAgVIANAAIAAgRIAaAAIAAARIAcAAIAAAVIgcAAIAAAfQAAAHADACQACACAHAAIAQAAIAAAXg");
	this.shape_51.setTransform(49.775,381.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.instance_18}]},85).wait(109));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-55,178,887,700.7);
// library properties:
lib.properties = {
	id: '4D8493913056614EB0724EA1A0BB048B',
	width: 420,
	height: 420,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Kausspsd.png", id:"Kausspsd"},
		{src:"images/koolpsd_0jpgcopy.jpg", id:"koolpsd_0jpgcopy"},
		{src:"images/peremetsas_alt.jpg", id:"peremetsas_alt"},
		{src:"images/väiksem.jpg", id:"väiksem"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4D8493913056614EB0724EA1A0BB048B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;